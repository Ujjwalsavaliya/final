const AWS = require('aws-sdk');
const xlsx = require('xlsx');

const s3 = new AWS.S3();

exports.handler = async (event) => {
    try {
        // Parse the incoming event body to extract the feedback data
        const feedbackData = JSON.parse(event.body);
        console.log('Received feedback:', feedbackData);

        // Create a new Excel workbook
        const workbook = xlsx.utils.book_new();
        const worksheet = xlsx.utils.json_to_sheet([feedbackData]);

        // Add the worksheet to the workbook
        xlsx.utils.book_append_sheet(workbook, worksheet, 'Feedback');

        // Convert the workbook to a buffer
        const excelBuffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });

        // Define S3 parameters
        const params = {
            Bucket: 'project4webapp',
            Key: `feedback/${Date.now()}_feedback.xlsx`,
            Body: excelBuffer,
            ContentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        };

        // Upload the file to S3
        await s3.putObject(params).promise();

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Feedback successfully saved to S3' })
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
};
